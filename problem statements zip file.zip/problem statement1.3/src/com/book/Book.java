package com.book;

public class Book {

}
